package th.ac.tu.cs.projectportal.entity;

public enum Gender {
    Male,
    Female,
    Other
}
