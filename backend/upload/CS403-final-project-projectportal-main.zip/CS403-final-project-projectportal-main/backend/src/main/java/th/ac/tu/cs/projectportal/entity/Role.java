package th.ac.tu.cs.projectportal.entity;

public enum Role {
    Student,
    Staff,
    Admin,
    Guest
}
